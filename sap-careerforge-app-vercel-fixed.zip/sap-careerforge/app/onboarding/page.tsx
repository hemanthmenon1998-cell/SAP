"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function Onboarding() {
  const router = useRouter();
  const [f, setF] = useState({
    display_name: "", job_title: "", years_experience: "0", industry: "",
    sap_knowledge: "none", learning_speed: "normal", target_path: "mm_sd", daily_target_minutes: "60",
  });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setErr(null);
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { router.push("/login"); return; }
    const { error } = await supabase.from("profiles").update({
      display_name: f.display_name, job_title: f.job_title, years_experience: Number(f.years_experience),
      industry: f.industry, sap_knowledge: f.sap_knowledge, learning_speed: f.learning_speed,
      target_path: f.target_path, daily_target_minutes: Number(f.daily_target_minutes), onboarding_completed: true,
    }).eq("id", user.id);
    if (error) { setErr("Could not save your profile. Please try again."); setBusy(false); return; }
    router.push("/dashboard"); router.refresh();
  }

  const field = "mt-1 w-full rounded-lg border border-slate-300 px-3 py-2";
  return (
    <main className="mx-auto max-w-xl px-6 py-12">
      <h1 className="text-2xl font-bold">Tell us about you</h1>
      <p className="mt-1 text-slate-600">We use this to set your daily study target. You can change it later.</p>
      <form onSubmit={save} className="mt-6 space-y-4">
        <div><label htmlFor="n" className="text-sm font-medium">Name</label><input id="n" required className={field} value={f.display_name} onChange={set("display_name")} /></div>
        <div className="grid grid-cols-2 gap-4">
          <div><label htmlFor="j" className="text-sm font-medium">Current job title</label><input id="j" className={field} value={f.job_title} onChange={set("job_title")} /></div>
          <div><label htmlFor="y" className="text-sm font-medium">Years of experience</label><input id="y" type="number" min="0" step="0.5" className={field} value={f.years_experience} onChange={set("years_experience")} /></div>
        </div>
        <div><label htmlFor="i" className="text-sm font-medium">Current industry</label><input id="i" className={field} value={f.industry} onChange={set("industry")} /></div>
        <div className="grid grid-cols-2 gap-4">
          <div><label htmlFor="k" className="text-sm font-medium">Current SAP knowledge</label>
            <select id="k" className={field} value={f.sap_knowledge} onChange={set("sap_knowledge")}>
              <option value="none">None</option><option value="basic">Basic</option><option value="some">Some</option><option value="working">Working knowledge</option>
            </select></div>
          <div><label htmlFor="s" className="text-sm font-medium">Learning speed</label>
            <select id="s" className={field} value={f.learning_speed} onChange={set("learning_speed")}>
              <option value="normal">Normal</option><option value="fast">Fast</option><option value="intensive">Intensive</option>
            </select></div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div><label htmlFor="t" className="text-sm font-medium">Target</label>
            <select id="t" className={field} value={f.target_path} onChange={set("target_path")}>
              <option value="mm_sd">MM + SD</option><option value="mm">SAP MM</option><option value="sd">SAP SD</option>
            </select></div>
          <div><label htmlFor="d" className="text-sm font-medium">Daily study target</label>
            <select id="d" className={field} value={f.daily_target_minutes} onChange={set("daily_target_minutes")}>
              <option value="30">30 minutes</option><option value="60">60 minutes</option><option value="90">90 minutes</option><option value="120">2 hours</option>
            </select></div>
        </div>
        {err && <p role="alert" className="text-sm text-red-600">{err}</p>}
        <button disabled={busy} className="w-full rounded-lg bg-brand-600 px-4 py-2.5 font-semibold text-white hover:bg-brand-700 disabled:opacity-60">
          {busy ? "Saving..." : "Start learning"}
        </button>
      </form>
    </main>
  );
}
