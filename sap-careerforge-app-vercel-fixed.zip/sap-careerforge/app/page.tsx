import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

export default async function Home() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  return (
    <main className="mx-auto max-w-4xl px-6 py-20">
      <p className="text-sm font-semibold uppercase tracking-wide text-brand-600">SAP CareerForge</p>
      <h1 className="mt-3 text-4xl font-bold sm:text-5xl">Learn SAP. Practice SAP. Become job-ready.</h1>
      <p className="mt-5 max-w-2xl text-lg text-slate-600">
        Master SAP S/4HANA MM and SD through structured lessons, knowledge checks and practical tasks.
        Your progress is saved to your account, so you can continue from any device.
      </p>
      <div className="mt-8 flex gap-3">
        <Link href={user ? "/dashboard" : "/login"} className="rounded-lg bg-brand-600 px-5 py-3 font-semibold text-white hover:bg-brand-700">
          {user ? "Go to dashboard" : "Start learning"}
        </Link>
      </div>
      <div className="mt-14 grid gap-4 sm:grid-cols-3">
        {[
          ["Real explanations", "Business context, SAP concepts, examples, common mistakes and troubleshooting in every lesson."],
          ["Earned progress", "A lesson completes only after you read it, pass its quiz and submit the practical task."],
          ["Honest by design", "Training and simulations are labelled as such. This is not SAP certification."],
        ].map(([t, d]) => (
          <div key={t} className="rounded-xl border border-slate-200 bg-white p-5">
            <h3 className="font-semibold">{t}</h3>
            <p className="mt-2 text-sm text-slate-600">{d}</p>
          </div>
        ))}
      </div>
    </main>
  );
}
