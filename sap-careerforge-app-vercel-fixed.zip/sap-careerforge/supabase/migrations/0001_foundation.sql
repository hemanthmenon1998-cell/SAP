-- SAP CareerForge — Phase 1 foundation
-- Auth, profiles, admin roles, curriculum content, progress, quizzes, notes, bookmarks.
-- All tables have RLS enabled. Authorization uses public.user_roles (never user metadata).

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------
-- Shared helpers
-- ---------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

create type public.app_role as enum ('learner', 'author', 'reviewer', 'admin');
create type public.content_status as enum ('draft', 'review', 'published', 'archived');
create type public.difficulty as enum ('beginner', 'intermediate', 'advanced', 'expert');
create type public.sap_module as enum ('fundamentals', 'mm', 'sd', 'integration', 'support', 'career');

-- ---------------------------------------------------------------
-- Roles (authorization source of truth)
-- ---------------------------------------------------------------
create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);
create index user_roles_user_id_idx on public.user_roles(user_id);
alter table public.user_roles enable row level security;

create or replace function public.has_role(_role public.app_role)
returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.user_roles
    where user_id = auth.uid() and role = _role
  );
$$;

create or replace function public.is_admin()
returns boolean
language sql stable security definer set search_path = public as $$
  select public.has_role('admin');
$$;

create or replace function public.is_content_editor()
returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.user_roles
    where user_id = auth.uid() and role in ('admin', 'author', 'reviewer')
  );
$$;

-- Users may read their own roles; only admins manage roles.
create policy "read own roles" on public.user_roles
  for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy "admin insert roles" on public.user_roles
  for insert to authenticated with check (public.is_admin());
create policy "admin update roles" on public.user_roles
  for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "admin delete roles" on public.user_roles
  for delete to authenticated using (public.is_admin());

-- ---------------------------------------------------------------
-- Profiles
-- ---------------------------------------------------------------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  job_title text,
  years_experience numeric(4,1) check (years_experience >= 0),
  industry text,
  sap_knowledge text check (sap_knowledge in ('none','basic','some','working')),
  learning_speed text check (learning_speed in ('fast','normal','intensive')) default 'normal',
  target_path text check (target_path in ('mm','sd','mm_sd')) default 'mm_sd',
  daily_target_minutes int check (daily_target_minutes in (30,60,90,120)) default 60,
  onboarding_completed boolean not null default false,
  xp int not null default 0 check (xp >= 0),
  level int not null default 1 check (level >= 1),
  current_streak int not null default 0 check (current_streak >= 0),
  longest_streak int not null default 0 check (longest_streak >= 0),
  last_active_date date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger profiles_updated before update on public.profiles
  for each row execute function public.set_updated_at();
alter table public.profiles enable row level security;

-- xp/level/streak are server-managed: users can edit profile fields only.
create policy "read own profile" on public.profiles
  for select to authenticated using (id = auth.uid());
create policy "insert own profile" on public.profiles
  for insert to authenticated with check (id = auth.uid());
create policy "update own profile" on public.profiles
  for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- Block client-side tampering with gamification counters.
create or replace function public.protect_profile_counters()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  -- auth.uid() is null for service-role and direct SQL calls, so only client sessions are locked.
  if auth.uid() is not null then
    new.xp := old.xp;
    new.level := old.level;
    new.current_streak := old.current_streak;
    new.longest_streak := old.longest_streak;
  end if;
  return new;
end $$;
create trigger profiles_protect_counters before update on public.profiles
  for each row execute function public.protect_profile_counters();

-- Auto-create profile + default learner role on signup.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'name', split_part(new.email, '@', 1)));
  insert into public.user_roles (user_id, role) values (new.id, 'learner');
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------
-- Curriculum content (versioned, workflow status)
-- ---------------------------------------------------------------
create table public.learning_paths (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  title text not null,
  description text,
  sap_module public.sap_module not null,
  level_number int check (level_number between 1 and 15),
  sort_order int not null default 0,
  status public.content_status not null default 'draft',
  version int not null default 1,
  author_id uuid references auth.users(id) on delete set null,
  reviewer_id uuid references auth.users(id) on delete set null,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.modules (
  id uuid primary key default gen_random_uuid(),
  learning_path_id uuid not null references public.learning_paths(id) on delete cascade,
  slug text not null unique,
  title text not null,
  summary text,
  sap_module public.sap_module not null,
  estimated_minutes int not null default 60 check (estimated_minutes > 0),
  pass_threshold int not null default 70 check (pass_threshold between 0 and 100),
  requires_lab boolean not null default false,
  sort_order int not null default 0,
  status public.content_status not null default 'draft',
  version int not null default 1,
  author_id uuid references auth.users(id) on delete set null,
  reviewer_id uuid references auth.users(id) on delete set null,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index modules_path_idx on public.modules(learning_path_id, sort_order);
create index modules_status_idx on public.modules(status);

create table public.lessons (
  id uuid primary key default gen_random_uuid(),
  module_id uuid not null references public.modules(id) on delete cascade,
  slug text not null unique,
  title text not null,
  learning_objective text not null,
  difficulty public.difficulty not null default 'beginner',
  estimated_minutes int not null default 20 check (estimated_minutes > 0),
  quiz_pass_threshold int not null default 70 check (quiz_pass_threshold between 0 and 100),
  requires_practical boolean not null default false,
  sort_order int not null default 0,
  status public.content_status not null default 'draft',
  version int not null default 1,
  author_id uuid references auth.users(id) on delete set null,
  reviewer_id uuid references auth.users(id) on delete set null,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index lessons_module_idx on public.lessons(module_id, sort_order);
create index lessons_status_idx on public.lessons(status);
create index lessons_difficulty_idx on public.lessons(difficulty);

-- The 16 lesson parts (business context, SAP concept, common mistakes, ...) live here.
create table public.lesson_sections (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  section_type text not null check (section_type in (
    'objective','business_context','sap_concept','why_exists','example','terminology',
    'diagram','steps','configuration','common_mistakes','troubleshooting',
    'knowledge_check','mini_quiz','practical_task','interview_question','completion_criteria')),
  title text,
  body jsonb not null default '{}'::jsonb,
  is_required boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index lesson_sections_lesson_idx on public.lesson_sections(lesson_id, sort_order);

create table public.topics (
  id uuid primary key default gen_random_uuid(),
  module_id uuid references public.modules(id) on delete set null,
  slug text not null unique,
  name text not null,
  created_at timestamptz not null default now()
);

do $$
declare t text;
begin
  foreach t in array array['learning_paths','modules','lessons','lesson_sections'] loop
    execute format('create trigger %I_updated before update on public.%I
      for each row execute function public.set_updated_at()', t, t);
  end loop;
end $$;

-- Content RLS: learners read published; editors read/write everything.
do $$
declare t text;
begin
  foreach t in array array['learning_paths','modules','lessons'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format($p$create policy "read published" on public.%I
      for select to authenticated using (status = 'published' or public.is_content_editor())$p$, t);
    execute format($p$create policy "editor insert" on public.%I
      for insert to authenticated with check (public.is_content_editor())$p$, t);
    execute format($p$create policy "editor update" on public.%I
      for update to authenticated using (public.is_content_editor()) with check (public.is_content_editor())$p$, t);
    execute format($p$create policy "admin delete" on public.%I
      for delete to authenticated using (public.is_admin())$p$, t);
  end loop;
end $$;

alter table public.lesson_sections enable row level security;
create policy "read sections of published lessons" on public.lesson_sections
  for select to authenticated using (
    public.is_content_editor()
    or exists (select 1 from public.lessons l where l.id = lesson_id and l.status = 'published'));
create policy "editor insert sections" on public.lesson_sections
  for insert to authenticated with check (public.is_content_editor());
create policy "editor update sections" on public.lesson_sections
  for update to authenticated using (public.is_content_editor()) with check (public.is_content_editor());
create policy "admin delete sections" on public.lesson_sections
  for delete to authenticated using (public.is_admin());

alter table public.topics enable row level security;
create policy "read topics" on public.topics for select to authenticated using (true);
create policy "editor write topics" on public.topics
  for all to authenticated using (public.is_content_editor()) with check (public.is_content_editor());

-- ---------------------------------------------------------------
-- Question bank + quizzes
-- ---------------------------------------------------------------
create table public.questions (
  id uuid primary key default gen_random_uuid(),
  module_id uuid references public.modules(id) on delete set null,
  lesson_id uuid references public.lessons(id) on delete set null,
  topic_id uuid references public.topics(id) on delete set null,
  question_type text not null check (question_type in (
    'multiple_choice','multiple_select','true_false','matching','ordering',
    'scenario','troubleshooting','configuration_decision','case_study','interview')),
  prompt text not null,
  difficulty public.difficulty not null default 'beginner',
  learning_objective text,
  explanation text not null,
  interview_relevance text,
  payload jsonb not null default '{}'::jsonb,   -- matching pairs / ordering items
  status public.content_status not null default 'draft',
  version int not null default 1,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index questions_module_idx on public.questions(module_id);
create index questions_lesson_idx on public.questions(lesson_id);
create index questions_difficulty_idx on public.questions(difficulty);
create index questions_status_idx on public.questions(status);

create table public.question_options (
  id uuid primary key default gen_random_uuid(),
  question_id uuid not null references public.questions(id) on delete cascade,
  label text not null,
  sort_order int not null default 0
);
create index question_options_q_idx on public.question_options(question_id);

-- Correct answers are kept OUT of client-readable tables. Scoring happens server-side.
create table public.question_answer_keys (
  question_id uuid primary key references public.questions(id) on delete cascade,
  correct_option_ids uuid[] not null default '{}',
  correct_payload jsonb not null default '{}'::jsonb
);

create trigger questions_updated before update on public.questions
  for each row execute function public.set_updated_at();

alter table public.questions enable row level security;
alter table public.question_options enable row level security;
alter table public.question_answer_keys enable row level security;

create policy "read published questions" on public.questions
  for select to authenticated using (status = 'published' or public.is_content_editor());
create policy "editor write questions" on public.questions
  for all to authenticated using (public.is_content_editor()) with check (public.is_content_editor());

create policy "read options" on public.question_options
  for select to authenticated using (
    public.is_content_editor()
    or exists (select 1 from public.questions q where q.id = question_id and q.status = 'published'));
create policy "editor write options" on public.question_options
  for all to authenticated using (public.is_content_editor()) with check (public.is_content_editor());

-- Answer keys: editors only. Learners never read them; server uses service role to score.
create policy "editor only answer keys" on public.question_answer_keys
  for all to authenticated using (public.is_content_editor()) with check (public.is_content_editor());

create table public.quizzes (
  id uuid primary key default gen_random_uuid(),
  module_id uuid references public.modules(id) on delete set null,
  lesson_id uuid references public.lessons(id) on delete set null,
  title text not null,
  kind text not null default 'lesson' check (kind in ('baseline','lesson','module','final','review')),
  pass_threshold int not null default 70 check (pass_threshold between 0 and 100),
  status public.content_status not null default 'draft',
  version int not null default 1,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.quiz_questions (
  quiz_id uuid not null references public.quizzes(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  sort_order int not null default 0,
  primary key (quiz_id, question_id)
);
create trigger quizzes_updated before update on public.quizzes
  for each row execute function public.set_updated_at();
alter table public.quizzes enable row level security;
alter table public.quiz_questions enable row level security;
create policy "read published quizzes" on public.quizzes
  for select to authenticated using (status = 'published' or public.is_content_editor());
create policy "editor write quizzes" on public.quizzes
  for all to authenticated using (public.is_content_editor()) with check (public.is_content_editor());
create policy "read quiz questions" on public.quiz_questions
  for select to authenticated using (true);
create policy "editor write quiz questions" on public.quiz_questions
  for all to authenticated using (public.is_content_editor()) with check (public.is_content_editor());

-- ---------------------------------------------------------------
-- Learner-owned data
-- ---------------------------------------------------------------
create table public.quiz_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  quiz_id uuid not null references public.quizzes(id) on delete cascade,
  score_percent numeric(5,2) check (score_percent between 0 and 100),
  passed boolean,
  started_at timestamptz not null default now(),
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index quiz_attempts_user_idx on public.quiz_attempts(user_id, created_at desc);
create index quiz_attempts_quiz_idx on public.quiz_attempts(quiz_id);

create table public.quiz_answers (
  id uuid primary key default gen_random_uuid(),
  attempt_id uuid not null references public.quiz_attempts(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  response jsonb not null default '{}'::jsonb,
  is_correct boolean,
  created_at timestamptz not null default now(),
  unique (attempt_id, question_id)
);
create index quiz_answers_user_idx on public.quiz_answers(user_id);

create table public.lesson_progress (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  sections_read int not null default 0 check (sections_read >= 0),
  activity_completed boolean not null default false,
  quiz_passed boolean not null default false,
  practical_completed boolean not null default false,
  status text not null default 'in_progress' check (status in ('not_started','in_progress','completed')),
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, lesson_id)
);
create index lesson_progress_user_idx on public.lesson_progress(user_id, status);

create table public.module_progress (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  module_id uuid not null references public.modules(id) on delete cascade,
  assessment_passed boolean not null default false,
  lab_completed boolean not null default false,
  status text not null default 'in_progress' check (status in ('not_started','in_progress','completed')),
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, module_id)
);
create index module_progress_user_idx on public.module_progress(user_id, status);

-- Idempotent event log: client-generated event_id makes offline retries safe.
create table public.progress_events (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null,
  user_id uuid not null references auth.users(id) on delete cascade,
  event_type text not null,
  payload jsonb not null default '{}'::jsonb,
  occurred_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  unique (user_id, event_id)
);
create index progress_events_user_idx on public.progress_events(user_id, created_at desc);

create table public.study_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  lesson_id uuid references public.lessons(id) on delete set null,
  started_at timestamptz not null default now(),
  duration_seconds int not null default 0 check (duration_seconds >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index study_sessions_user_idx on public.study_sessions(user_id, created_at desc);

create table public.notes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  lesson_id uuid references public.lessons(id) on delete cascade,
  title text,
  body text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index notes_user_idx on public.notes(user_id, created_at desc);

create table public.bookmarks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  target_type text not null check (target_type in ('lesson','question','glossary','case_study','ticket','lab')),
  target_id uuid not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, target_type, target_id)
);
create index bookmarks_user_idx on public.bookmarks(user_id);

do $$
declare t text;
begin
  foreach t in array array[
    'quiz_attempts','lesson_progress','module_progress','study_sessions','notes','bookmarks'
  ] loop
    execute format('create trigger %I_updated before update on public.%I
      for each row execute function public.set_updated_at()', t, t);
  end loop;

  -- Own-row policies; UPDATE checks both existing row (USING) and new ownership (WITH CHECK).
  foreach t in array array[
    'quiz_attempts','quiz_answers','lesson_progress','module_progress',
    'progress_events','study_sessions','notes','bookmarks'
  ] loop
    execute format('alter table public.%I enable row level security', t);
    execute format($p$create policy "select own" on public.%I
      for select to authenticated using (user_id = auth.uid())$p$, t);
    execute format($p$create policy "insert own" on public.%I
      for insert to authenticated with check (user_id = auth.uid())$p$, t);
  end loop;

  foreach t in array array[
    'quiz_attempts','lesson_progress','module_progress','study_sessions','notes','bookmarks'
  ] loop
    execute format($p$create policy "update own" on public.%I
      for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid())$p$, t);
  end loop;

  foreach t in array array['notes','bookmarks'] loop
    execute format($p$create policy "delete own" on public.%I
      for delete to authenticated using (user_id = auth.uid())$p$, t);
  end loop;
end $$;

-- Security note: quiz_attempts/lesson_progress scoring fields (score_percent, passed,
-- quiz_passed, status, completed_at) must be written by server code using the service
-- role after deterministic validation. Phase 1 follow-up: revoke UPDATE on those columns
-- from the authenticated role, or move completion into a security-definer RPC.

-- ---------------------------------------------------------------
-- Function privileges: trigger functions are not callable as RPC;
-- role helpers are for signed-in users only.
-- ---------------------------------------------------------------
revoke execute on function public.handle_new_user() from public, anon, authenticated;
revoke execute on function public.protect_profile_counters() from public, anon, authenticated;
revoke execute on function public.has_role(public.app_role) from public, anon;
revoke execute on function public.is_admin() from public, anon;
revoke execute on function public.is_content_editor() from public, anon;
grant execute on function public.has_role(public.app_role) to authenticated;
grant execute on function public.is_admin() to authenticated;
grant execute on function public.is_content_editor() to authenticated;
