"use client";
import { useState } from "react";
import Link from "next/link";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { createClient } from "@/lib/supabase/client";

type Section = { id: string; section_type: string; title: string | null; body: { markdown?: string }; is_required: boolean };
type Q = { id: string; prompt: string; type: string; options: { id: string; label: string }[] };
type Progress = { sections_read: number; quiz_passed: boolean; practical_completed: boolean; status: string };
type QuizResult = { score: number; passed: boolean; pass_threshold: number; correct: number; total: number; results: { question_id: string; correct: boolean; explanation: string }[] };

export default function LessonView(props: {
  lesson: { id: string; title: string; learning_objective: string; estimated_minutes: number; difficulty: string };
  sections: Section[]; quizId: string | null; passThreshold: number; questions: Q[]; initial: Progress;
}) {
  const supabase = createClient();
  const { lesson, sections, quizId, questions } = props;
  const required = sections.filter((s) => s.is_required);
  const [read, setRead] = useState(props.initial.sections_read);
  const [quizPassed, setQuizPassed] = useState(props.initial.quiz_passed);
  const [practicalDone, setPracticalDone] = useState(props.initial.practical_completed);
  const [status, setStatus] = useState(props.initial.status);
  const [answers, setAnswers] = useState<Record<string, string[]>>({});
  const [result, setResult] = useState<QuizResult | null>(null);
  const [practical, setPractical] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  function apply(row: any) {
    if (!row) return;
    setRead(row.sections_read ?? 0); setQuizPassed(!!row.quiz_passed);
    setPracticalDone(!!row.practical_completed); setStatus(row.status ?? "in_progress");
  }

  async function markRead(index: number) {
    setBusy("read"); setError(null);
    const { data, error } = await supabase.rpc("record_section_progress", { p_lesson_id: lesson.id, p_sections_read: index + 1 });
    setBusy(null);
    if (error) { setError("Could not save your progress. Check your connection and try again."); return; }
    apply(data);
  }

  function toggle(q: Q, optionId: string) {
    setAnswers((prev) => {
      const cur = prev[q.id] ?? [];
      if (q.type === "multiple_select") return { ...prev, [q.id]: cur.includes(optionId) ? cur.filter((x) => x !== optionId) : [...cur, optionId] };
      return { ...prev, [q.id]: [optionId] };
    });
  }

  async function submitQuiz() {
    if (!quizId) return;
    setBusy("quiz"); setError(null);
    const { data, error } = await supabase.rpc("submit_quiz", { p_quiz_id: quizId, p_answers: answers });
    setBusy(null);
    if (error) { setError("Could not submit the quiz. Please try again."); return; }
    setResult(data as QuizResult);
    if ((data as QuizResult).passed) setQuizPassed(true);
    const { data: lp } = await supabase.from("lesson_progress").select("sections_read, quiz_passed, practical_completed, status").eq("lesson_id", lesson.id).maybeSingle();
    apply(lp);
  }

  async function submitPractical() {
    setBusy("practical"); setError(null);
    const { data, error } = await supabase.rpc("submit_practical", { p_lesson_id: lesson.id, p_text: practical });
    setBusy(null);
    if (error) { setError(error.message.includes("80 characters") ? "Please write at least 80 characters." : "Could not save your submission. Please try again."); return; }
    apply(data);
  }

  const allRead = read >= required.length;
  const allAnswered = questions.length > 0 && questions.every((q) => (answers[q.id] ?? []).length > 0);

  return (
    <div className="max-w-3xl">
      <Link href="/learn" className="text-sm text-brand-600 hover:underline">← All lessons</Link>
      <h1 className="mt-2 text-2xl font-bold">{lesson.title}</h1>
      <p className="mt-1 text-sm text-slate-500">{lesson.estimated_minutes} min · {lesson.difficulty}</p>

      <div className="mt-4 flex flex-wrap gap-2 text-xs font-semibold">
        <span className={`rounded-full px-3 py-1 ${allRead ? "bg-green-100 text-green-800" : "bg-slate-100 text-slate-600"}`}>Read {Math.min(read, required.length)}/{required.length}</span>
        <span className={`rounded-full px-3 py-1 ${quizPassed ? "bg-green-100 text-green-800" : "bg-slate-100 text-slate-600"}`}>Quiz {quizPassed ? "passed" : "not passed"}</span>
        <span className={`rounded-full px-3 py-1 ${practicalDone ? "bg-green-100 text-green-800" : "bg-slate-100 text-slate-600"}`}>Practical {practicalDone ? "submitted" : "pending"}</span>
        {status === "completed" && <span className="rounded-full bg-brand-600 px-3 py-1 text-white">Lesson completed</span>}
      </div>

      <div className="mt-6 space-y-4">
        {sections.map((s, i) => {
          const unlocked = i <= read;
          const isRead = i < read;
          return (
            <section key={s.id} className="rounded-xl border border-slate-200 bg-white p-5">
              <h2 className="font-semibold">{s.title}</h2>
              {unlocked ? (
                <>
                  <div className="md mt-2 text-sm"><div className="tablewrap"><ReactMarkdown remarkPlugins={[remarkGfm]}>{s.body.markdown ?? ""}</ReactMarkdown></div></div>
                  {!isRead && (
                    <button disabled={busy === "read"} onClick={() => markRead(i)} className="mt-3 rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700 disabled:opacity-60">
                      {busy === "read" ? "Saving..." : i === sections.length - 1 ? "Finish reading" : "I've read this, continue"}
                    </button>
                  )}
                </>
              ) : <p className="mt-1 text-sm text-slate-400">Locked until you finish the previous section.</p>}
            </section>
          );
        })}
      </div>

      {allRead && quizId && (
        <section className="mt-8 rounded-xl border border-slate-200 bg-white p-5">
          <h2 className="text-lg font-semibold">Knowledge check</h2>
          <p className="text-sm text-slate-600">You need {props.passThreshold}% to pass. You can retry.</p>
          <div className="mt-4 space-y-6">
            {questions.map((q, qi) => {
              const r = result?.results.find((x) => x.question_id === q.id);
              return (
                <fieldset key={q.id}>
                  <legend className="font-medium">{qi + 1}. {q.prompt}{q.type === "multiple_select" && <span className="ml-2 text-xs text-slate-500">(select all that apply)</span>}</legend>
                  <div className="mt-2 space-y-2">
                    {q.options.map((o) => (
                      <label key={o.id} className="flex cursor-pointer items-start gap-2 text-sm">
                        <input type={q.type === "multiple_select" ? "checkbox" : "radio"} name={q.id} checked={(answers[q.id] ?? []).includes(o.id)} onChange={() => toggle(q, o.id)} className="mt-1" />
                        <span>{o.label}</span>
                      </label>
                    ))}
                  </div>
                  {r && (
                    <p className={`mt-2 rounded-lg p-3 text-sm ${r.correct ? "bg-green-50 text-green-800" : "bg-amber-50 text-amber-800"}`}>
                      <strong>{r.correct ? "Correct. " : "Not quite. "}</strong>{r.explanation}
                    </p>
                  )}
                </fieldset>
              );
            })}
          </div>
          {result && <p className={`mt-4 font-semibold ${result.passed ? "text-green-700" : "text-amber-700"}`}>Score {result.score}% ({result.correct}/{result.total}). {result.passed ? "Passed." : "Review the explanations and try again."}</p>}
          <button disabled={!allAnswered || busy === "quiz"} onClick={submitQuiz} className="mt-4 rounded-lg bg-brand-600 px-4 py-2 font-semibold text-white hover:bg-brand-700 disabled:opacity-50">
            {busy === "quiz" ? "Checking..." : result ? "Submit again" : "Submit answers"}
          </button>
        </section>
      )}

      {allRead && (
        <section className="mt-6 rounded-xl border border-slate-200 bg-white p-5">
          <h2 className="text-lg font-semibold">Practical task</h2>
          <p className="text-sm text-slate-600">Write your answer to the practical task above (training exercise). Your submission is saved to your account.</p>
          {practicalDone ? <p className="mt-3 text-sm font-semibold text-green-700">Submitted.</p> : (
            <>
              <label htmlFor="practical" className="sr-only">Practical task answer</label>
              <textarea id="practical" rows={6} value={practical} onChange={(e) => setPractical(e.target.value)} className="mt-3 w-full rounded-lg border border-slate-300 p-3 text-sm" />
              <button disabled={busy === "practical" || practical.trim().length < 80} onClick={submitPractical} className="mt-3 rounded-lg bg-brand-600 px-4 py-2 font-semibold text-white hover:bg-brand-700 disabled:opacity-50">
                {busy === "practical" ? "Saving..." : "Submit practical"}
              </button>
            </>
          )}
        </section>
      )}
      {error && <p role="alert" className="mt-4 text-sm text-red-600">{error}</p>}
    </div>
  );
}
